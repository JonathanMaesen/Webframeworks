export const Home = () => {
  return(
      <>
          <h2>Welkom op dit, het tussentijdse examen van Jonathan Maesen</h2>
          <p>wij vragen voor uw vriendelijke verbeteringen op gebogen knietjes.</p>
      </>
  )
}