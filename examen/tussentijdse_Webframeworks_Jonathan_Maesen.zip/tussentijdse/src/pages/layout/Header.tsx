import {Nav} from "./NavBar.tsx";

export function Header() {
return  (
    <header>
        <h1>Tussentijdse toets 2025</h1>
        <Nav/>
    </header>
)
}

