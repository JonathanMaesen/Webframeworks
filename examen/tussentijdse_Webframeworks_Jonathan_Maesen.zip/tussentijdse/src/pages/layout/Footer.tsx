import styles from './App.module.css';

export function Footer() {
    return(
        <footer className={styles.Footer}>
            <p>© 2025 Ducky Corporation. All rights reserved.</p>
        </footer>
    )
}